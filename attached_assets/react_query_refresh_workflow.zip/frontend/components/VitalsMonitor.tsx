
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

const VitalsMonitor = ({ patientId }: { patientId: number }) => {
  const queryClient = useQueryClient();

  const { data: vitals, isLoading, isError } = useQuery(['vitals', patientId], () =>
    axios.get(`/api/patients/${patientId}/vitals`).then(r => r.data)
  );

  const recordVitals = useMutation(
    (newVitals) => axios.post(`/api/patients/${patientId}/vitals`, newVitals),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['vitals', patientId]);
      }
    }
  );

  if (isLoading) return <p>Loading vitals...</p>;
  if (isError) return <p>Error loading vitals.</p>;

  const handleRecord = async () => {
    const newVitals = { bloodPressure: '120/80', heartRate: 72, temperature: 36.7 };
    await recordVitals.mutateAsync(newVitals);
  };

  return (
    <div>
      <h2>Vitals</h2>
      <ul>
        {vitals.map((v) => (
          <li key={v.id}>{v.bloodPressure} - {v.heartRate} bpm</li>
        ))}
      </ul>
      <button onClick={handleRecord} className="bg-green-500 text-white px-4 py-2 rounded mt-2">Record Vitals</button>
    </div>
  );
};

export default VitalsMonitor;
    